#pragma once
// Base class
class Object {
public:
    virtual void OnCollisionEnter(Object& other) {
    }
};

// Derived classes
class Player : public Object {
public:
    void OnCollisionEnter(Object& other) override {
    }
    void Draw(float x, float y, float width, float height);
};

class EnemyBlock : public Object {
public:
    void OnCollisionEnter(Object& other) override {
    }
    void heightdraw(float x, float y, float width, float height);
    void lowdraw(float x, float y, float width, float height);
};

class Floor : public Object {
public:
    void OnCollisionEnter(Object& other) override {
    }
    void Draw(float x, float y, float width, float height);
};

class Star : public Object {
public:
    void OnCollisionEnter(Object& other) override {
    }
};



