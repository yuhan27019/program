﻿#pragma comment(lib, "Opengl32.lib")

#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>

#ifdef _DEBUG
#define DBG_NEW new ( _NORMAL_BLOCK , __FILE__ , __LINE__ )
#else
#define DBG_NEW new
#endif

#include <GLFW/glfw3.h>
#include <stdio.h>
#include <chrono>
#include <thread>
#include <cmath>
#include "Object.h"

// 전역 변수로 Player와 Floor 객체 선언
Player player;
Floor ground;
EnemyBlock enemy;


// Player의 초기 위치와 크기 설정
float playerX = -0.8f;
float playerY = -0.7f;
float playerwidth = 0.1f;
float playerheigh = 0.14f;


// Ground의 초기 위치와 크기 설정
float groundX = -1.0f;
float groundY = -1.0f;
float groundWidth = 2.0f;
float groundHeight = 0.3f;

float block1X = 0.0f;
float block1Y = -0.7f;
float block1Width = 0.1f;
float block1Height = 0.2f;

float block2X = 0.5f;
float block2Y = -0.7f;
float block2Width = 0.1f;
float block2Height = 0.6f;

float block3X = 0.8f;
float block3Y = -0.7f;
float block3Width = 0.1f;
float block3Height = 0.2f;

float block4X = 0.7f;
float block4Y = -0.7f;
float block4Width = 0.1f;
float block4Height = 0.6f;
void errorCallback(int error, const char* description)
{
    printf("GLFW Error: %s", description);
}

void keyCallback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
    // 키 입력에 대한 처리
}

int Physics()
{
    // 물리 업데이트 로직
    return 0;
}

int Initialize()
{
    // 초기화 로직
    return 0;
}

int Update()
{
    // 업데이트 로직
    return 0;
}

int Render()
{
    // 배경색 설정 (R: 0, G: 30, B: 100)
    glClearColor(0.0f, 30.0f / 255.0f, 100.0f / 255.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    // Player와 Ground를 렌더링
    player.Draw(playerX, playerY, playerwidth, playerheigh);
    ground.Draw(groundX, groundY, groundWidth, groundHeight);
    enemy.heightdraw(block1X, block1Y, block1Width, block1Height);
    enemy.lowdraw(block2X, block2Y, block2Width, block2Height);
    enemy.heightdraw(block3X, block3Y, block3Width, block3Height);
    enemy.lowdraw(block4X, block4Y, block4Width, block4Height);

    return 0;
}

int main(void)
{
    _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

    // GLFW 라이브러리 초기화
    if (!glfwInit())
        return -1;

    GLFWwindow* window;
    window = glfwCreateWindow(800, 600, "Google Dino Run Copy Game", NULL, NULL);

    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    glfwMakeContextCurrent(window);
    glfwSetErrorCallback(errorCallback);
    glfwSetKeyCallback(window, keyCallback);

    Initialize();

    while (!glfwWindowShouldClose(window))
    {
        glfwPollEvents();
        Physics();
        Update();
        Render();
        glfwSwapBuffers(window);
    }

    glfwTerminate();
    return 0;
}

