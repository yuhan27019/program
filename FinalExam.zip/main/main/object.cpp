// object.cpp ����
#include "object.h"
#include <GLFW/glfw3.h>



void Player::Draw(float x, float y, float width, float height) {
    // OpenGL�� ����Ͽ� �÷��̾ �׸��� �ڵ� �ۼ�
    glBegin(GL_QUADS);
    glColor3f(1.0f, 0.0f, 0.0f); // ������ ����
    glVertex2f(x, y);
    glVertex2f(x + width, y);
    glVertex2f(x + width, y + height);
    glVertex2f(x, y + height);
    glEnd();

    glColor3f(0.0f, 0.0f, 0.0f);
    // �׵θ� �׸���
    glLineWidth(3.0f); // ���� �β� ����

    glBegin(GL_LINE_LOOP);
    glVertex2f(x, y);
    glVertex2f(x + width, y);
    glVertex2f(x + width, y + height);
    glVertex2f(x, y + height);    // ���� ��
    glEnd();
}

void Floor::Draw(float x, float y, float width, float height)
{
    glBegin(GL_QUADS);
    glColor3f(1.0f, 0.7843f, 0.0588f);
    glVertex2f(x, y);
    glVertex2f(x + width, y);
    glVertex2f(x + width, y + height);
    glVertex2f(x, y + height);
    glEnd();
}

void EnemyBlock::heightdraw(float x, float y, float width, float height)
{
    glBegin(GL_QUADS);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex2f(x, y);
    glVertex2f(x + width, y);
    glVertex2f(x + width, y + height);
    glVertex2f(x, y + height);
    glEnd();
}

void EnemyBlock::lowdraw(float x, float y, float width, float height)
{
    glBegin(GL_QUADS);
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex2f(x, y);
    glVertex2f(x + width, y);
    glVertex2f(x + width, y + height);
    glVertex2f(x, y + height);
    glEnd();
}
